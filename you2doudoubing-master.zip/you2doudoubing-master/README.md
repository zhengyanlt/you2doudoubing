


**一键部署到heroku：**  [![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

提供现成的YouTube API：
```
AIzaSyARHJJDFtwb5wcnURwwJA3FQRrM16PF27c
```
想要使用自己的youtube api可以在参考这里：https://you2php.github.io/doc/#getapi


**htpasswd网页锁** 账号密码在线生成：http://www.htaccesstools.com/htpasswd-generator/   


**豆豆兵频道：**  https://www.youtube.com/channel/UClceV39J1Z_9D4_mHkBZrMg

 
        
       
        
       
          
          
参考来源：

FORK于：https://github.com/bclswl0827/youtube-mirror-site-bclswl

参考于：https://github.com/onplus/you2php-heroku

下一步：https://github.com/hahadaba/YOU2PHP-GL-SELECTOR


