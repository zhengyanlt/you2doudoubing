<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyARHJJDFtwb5wcnURwwJA3FQRrM16PF27c');
define('GJ_CODE', 'JP');
define('SITE_NAME', '大爷常来玩儿啊');
define('TITLENAME', 'DouDouTube');
define('EN2DEKEY', 'lujianbupingyishenghou');
define('EMAIL', 'xiaofufua@protonmail.com');
?>
